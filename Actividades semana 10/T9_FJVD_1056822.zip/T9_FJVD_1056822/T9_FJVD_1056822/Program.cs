﻿using T9_FJVD_1056822;

Motocicleta objmotocicleta = new Motocicleta();
Console.Write("ingrese el modelo de la motocicleta: ");
objmotocicleta.Modelo = Console.ReadLine();
Console.Write("ingrese la marca de la motocicleta: ");
objmotocicleta.Marca = Console.ReadLine();
Console.Write("Ingrese el precio de la motocicleta: ");
objmotocicleta.Precio = Convert.ToDouble(Console.ReadLine());
Console.Write("Ingrese el valor del Iva: ");
objmotocicleta.Iva = Convert.ToDouble(Console.ReadLine());

 
Console.Write("Modelo: " + objmotocicleta.Modelo + ", Marca: " + objmotocicleta.Marca + ", Precio: " + objmotocicleta.Precio);
if (objmotocicleta.Iva >= 0.01 && objmotocicleta.Iva <= 0.99)
{
    Console.WriteLine(", Iva " + objmotocicleta.Iva);
}
else
{
    Console.WriteLine(", El porcentaje de iva ingresado es incorrecto");
}


Console.WriteLine("el precio sin iva de la motocicleta es: " + objmotocicleta.Precio);


if (objmotocicleta.Iva >= 0.01 && objmotocicleta.Iva <= 0.99)
{
    objmotocicleta.DefinirIva(objmotocicleta.Iva);
    Console.WriteLine("El monto del iva es de: " + objmotocicleta.Iva);
    objmotocicleta.DefinirPrecio(objmotocicleta.Iva);
    Console.WriteLine("El precio con iva es de: " + objmotocicleta.Iva);
}
else
{
    Console.WriteLine("el porcentaje de iva ingresado es incorrecto");
}

