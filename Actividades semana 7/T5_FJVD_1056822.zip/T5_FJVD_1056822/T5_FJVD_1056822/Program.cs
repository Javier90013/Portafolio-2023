﻿        Console.WriteLine("Ingrese la cantidad de la compra: ");
        string cantidad = Console.ReadLine();

        if (!decimal.TryParse(cantidad, out decimal compra))
        {
            Console.WriteLine("Monto no válido. Ingrese un número válido.");
            return;
        }

        decimal descuento = 0;

        if (compra < 400)
        {
            descuento = 0;
        }
        else if (compra >= 400 && compra <= 1000)
        {
            descuento = compra * 0.07m;
        }
        else if (compra > 1000 && compra <= 5000)
        {
            descuento = compra * 0.10m;
        }
        else if (compra > 5000 && compra <= 15000)
        {
            descuento = compra * 0.15m;
        }
        else if (compra > 15000)
        {
            descuento = compra * 0.25m;
        }

        Console.WriteLine("¿Tiene un codigo de descuento? (si/no)");
        string codigo = Console.ReadLine();

        if (string.Equals(codigo, "si", StringComparison.OrdinalIgnoreCase))
        {
            descuento += compra * 0.05m;
        }

        decimal pago = compra - descuento;

        Console.WriteLine("La cantidad a pagar es de: Q" + pago);
