﻿using Lab_10_FJVD_1056822;

class Program
{
    static void Main()
    {
        Console.Write("Introduce la longitud del cateto A (en metros): ");
        double catetoA = Convert.ToDouble(Console.ReadLine());
        Console.Write("Introduce la amplitud del ángulo opuesto al cateto A (en grados): ");
        double anguloOpuestoA = Convert.ToDouble(Console.ReadLine());

        TrianguloRectangulo objTriangulo = new TrianguloRectangulo(catetoA, anguloOpuestoA);

        Console.WriteLine("Resultados");
        Console.WriteLine($"Valor de cateto A: {objTriangulo.ObtenerCatetoA()} metros");
        Console.WriteLine($"Valor de cateto B: {objTriangulo.ObtenerCatetoB()} metros");
        Console.WriteLine($"Valor de hipotenusa: {objTriangulo.ObtenerHipotenusa()} metros");
        Console.WriteLine($"Valor de ángulo opuesto de A: {objTriangulo.ObtenerAnguloOpuestoA()} grados");
        Console.WriteLine($"Valor de ángulo opuesto de B: {objTriangulo.ObtenerAnguloOpuestoB()} grados");
        Console.WriteLine($"Valor de área: {objTriangulo.ObtenerArea()} metros cuadrados");
    }
}
