﻿Console.WriteLine("Ingrese su nombre:");
string nombre = Console.ReadLine();
Console.WriteLine("Ingrese su carné:");
double carne = Convert.ToDouble(Console.ReadLine());
Console.WriteLine("Ingrese cantidad de dinero:");
double dinero = Convert.ToDouble(Console.ReadLine());
int billetes100 = 0;
int billetes50 = 0;
Console.WriteLine(nombre + " " + carne);
if (dinero > 0 && dinero <= 999.99)
{
    if (dinero >= 100)
    {
        billetes100 = (int)(dinero / 100);
        Console.WriteLine("Cantidad de billetes de 100: " + billetes100);
    }
    int resultado100 = (int)(dinero % 100);
    if (resultado100 >= 50 && resultado100 < 100)
    {
        billetes50 = (int)(resultado100 / 50);
        Console.WriteLine("Cantidad de billetes de 50: " + billetes50);
    }
    int resultado50 = (int)(resultado100 % 50);
    if (resultado50 >= 20 && resultado50 < 50)
    {
        int billetes20 = (int)(resultado50 / 20);
        Console.WriteLine("Cantidad de billetes de 20: " + billetes20);
    }
    int resultado20 = (int)(resultado50 % 20); 
    if (resultado20 >= 10 && resultado20 < 20)
    {
        int billetes10 = (int)(resultado20 / 10);
        Console.WriteLine("Cantidad de billetes de 10: " + billetes10);
    }
    int resultado10 = (int)(resultado20 % 10);
    if (resultado10 >= 5 && resultado10 < 10)
    {
        int billetes5 = (int)(resultado10 / 5);
        Console.WriteLine("Cantidad de billetes de 5: " + billetes5);
    }
    int resultado5 = (int)(resultado10 % 5);
    if (resultado5 >= 1 && resultado5 < 5)
    {
        int monedas1 = (int)(resultado5 / 1);
        Console.WriteLine("Cantidad de monedas de Q1: " + monedas1);  //hasta aca funciona, a partir de aca no muestra los decimales
    }
    int resultado1 = (int)(resultado5 % 1);
    Console.WriteLine(resultado1);    //esto lo puse para ver el valor que calcula de resultado1  
    if (resultado5 >= 0.25 && resultado5 < 1)
    {
        int monedas0_25 = (int)(resultado1 / 0.25);
        Console.WriteLine("Cantidad de monedas de Q0.25: " + monedas0_25);
    }
    int resultado0_25 = (int)(resultado1 % 0.25);
    Console.WriteLine(resultado0_25);        //esto lo puse para ver el valor que calcula de resultado0_25
    if (resultado0_25 >= 0.1 && resultado0_25 < 0.25)
    {
        int monedas0_1 = (int)(resultado0_25 / 0.1);
        Console.WriteLine("Cantidad de monedas de Q1: " + monedas0_1);
    }
}
