﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T9_FJVD_1056822
{
    internal class Motocicleta
    {
        private string modelo;
        private double precio;
        private string marca;
        private double iva;

        public string Modelo { get => modelo; set => modelo = value; }
        public double Precio { get => precio; set => precio = value; }
        public string Marca { get => marca; set => marca = value; }
        public double Iva { get => iva; set => iva = value; }

        public void Mostrardatos (string _modelo, double _precio, string _marca, double _iva)
        {
            this.modelo = _modelo;
            this.precio = _precio;
            this.marca = _marca;
            this.iva = _iva;
        }
        public void DefinirIva(double _iva)
        {
            this.iva = _iva;
        }
        public void DefinirPrecio (double v)
        {
            v = ((precio * iva) + precio);
            this.iva = v;
        }
    }
}
