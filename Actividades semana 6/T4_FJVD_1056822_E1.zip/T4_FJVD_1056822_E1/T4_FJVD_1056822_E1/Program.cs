﻿Console.WriteLine("Ingrese Velocidad inicial del objeto");
int Vo = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Ingrese valor de la aceleración ");
int a = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Ingrese el tiempo que tarda el objeto");
int  t = Convert.ToInt32(Console.ReadLine()); 
Console.WriteLine("El resultado es: " + (Vo+a*t) + " m/s");
