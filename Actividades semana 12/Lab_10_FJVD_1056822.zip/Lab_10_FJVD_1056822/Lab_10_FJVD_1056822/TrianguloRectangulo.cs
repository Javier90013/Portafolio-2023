﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_10_FJVD_1056822
{
    internal class TrianguloRectangulo
    {
         private double catetoA;
    private double anguloOpuestoA;

    public TrianguloRectangulo(double catetoA, double anguloOpuestoA)
    {
        this.catetoA = catetoA;
        this.anguloOpuestoA = anguloOpuestoA;
    }

    public double ObtenerCatetoA()
    {
        return catetoA;
    }

    public double ObtenerCatetoB()
    {
        double angulo = Math.PI * anguloOpuestoA / 180.0;
        return Math.Round(catetoA / Math.Tan(angulo), 3);
    }

    public double ObtenerHipotenusa()
    {
        return Math.Round(catetoA / Math.Sin(anguloOpuestoA * Math.PI / 180.0), 3);
    }

    public double ObtenerAnguloOpuestoA()
    {
        return anguloOpuestoA;
    }

    public double ObtenerAnguloOpuestoB()
    {
        return Math.Round(90.0 - anguloOpuestoA, 3);
    }

    public double ObtenerArea()
    {
        return Math.Round(0.5 * catetoA * this.ObtenerCatetoB(), 3);
    }
    }
}
